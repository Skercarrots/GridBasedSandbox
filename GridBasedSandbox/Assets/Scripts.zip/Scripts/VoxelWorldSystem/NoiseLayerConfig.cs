using UnityEngine;

// ─────────────────────────────────────────────────────────────────────────────
//  NoiseLayerConfig — One tunable fBm noise layer (scale, octaves, persistence,
//  lacunarity, and a per-layer seed offset so multiple layers sampled with the
//  same world seed don't line up with each other).
//
//  Used by OverworldGenerator for continentalness / erosion / temperature /
//  humidity — each gets its own instance so they can be tuned independently
//  in the Inspector, instead of one noise curve driving everything.
// ─────────────────────────────────────────────────────────────────────────────

[System.Serializable]
public class NoiseLayerConfig
{
    [Tooltip("Noise scale — larger = smoother/slower-changing.")]
    public float scale = 200f;

    [Tooltip("Number of fBm octaves for this layer.")]
    [Range(1, 6)] public int octaves = 3;

    [Tooltip("Amplitude falloff per octave.")]
    [Range(0f, 1f)] public float persistence = 0.5f;

    [Tooltip("Frequency growth per octave.")]
    [Range(1f, 4f)] public float lacunarity = 2f;

    [Tooltip("Multiplies the world seed before offsetting this layer's sample " +
             "point, so different layers don't sample identical noise at identical coords.")]
    public float seedOffsetMultiplier = 1f;

    /// <summary>Samples this layer at world (wx, wz). Returns a normalised [0..1] value.</summary>
    public float Sample(int wx, int wz, int seed)
    {
        float offset = seed * 0.1f * seedOffsetMultiplier;

        float amplitude = 1f;
        float frequency = 1f;
        float value = 0f;
        float maxValue = 0f;

        for (int o = 0; o < octaves; o++)
        {
            float sampleX = (wx + offset) / scale * frequency;
            float sampleZ = (wz + offset) / scale * frequency;

            value += Mathf.PerlinNoise(sampleX, sampleZ) * amplitude;
            maxValue += amplitude;

            amplitude *= persistence;
            frequency *= lacunarity;
        }

        return value / maxValue;
    }
}